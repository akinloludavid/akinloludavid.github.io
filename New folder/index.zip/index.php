<?php

// echo "<h3>Hello World <h3>";
// echo(rand(100000000000, 999999999999))


for ($i = 1; $i <= 200; $i++) {
    echo "$i. ";
    echo  ( rand(100000000000, 999999999999)) . " <hr>";
}
?>